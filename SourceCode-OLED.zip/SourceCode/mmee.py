from machine import Pin, I2C
from ssd1306 import SSD1306_I2C

i2c=I2C(1, scl=Pin(15), sda=Pin(14), freq=200000)
oled = SSD1306_I2C(128, 64, i2c)

basex=64
basey=32

def drawBox(mylength):
    for position in range(0,mylength):
        oled.pixel(position+basex, basey, 1)    

while True:
    oled.fill(0)
    oled.text("Hello Test", 0, 0)
    oled.pixel(0,10,1)  #(x, y, color)
    
    drawBox(100)
    
    oled.show()